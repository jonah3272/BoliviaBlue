December 16–17, 2025 archival observations and reproducible calculations
Prepared October 17, 2026 UTC. This is dated evidence, not a live quote or a publication receipt.

192 observations: 96 per Bolivia calendar day (America/La_Paz, UTC−4). All source_observation and official_observation values are null. The stored values do not identify original offers, per-reading platforms, quote age or calculation versions. Numeric consistency cannot recover provenance. Historical USDT/BOB code supplies unit context only.

The late jump on December 17 begins at 21:57:51 local. Original article creation around 20:00 preceded it; the original 9.23/9.18 quotes matched the 19:57:51 snapshot. Do not interpret the retrospective as proof the original article ignored available late readings. Daily median changes (+0.43% buy, +0.33% sell) differ from first-to-last changes (+13.21%, +11.23%); all observations, including anomalies, remain included. No verified market-wide, cash-dollar, official-premium, volume, or causal claim follows.

Run python recalculate.py in this directory using Python 3.9+ and available timezone data. It reads only the supplied JSON and writes local calculations.json and observations-dec16-17.csv. No network, database, installation, or credentials are used. rates-screened.json contains only these 192 December rows, filtered from the wider original screen. extract-observations.sql documents an equivalent bounded read; it is not executed automatically.

The actual retrospective revision date, if publication is approved, must come from the successful article transaction's updated_at. It is not this preparation date or either observation date.
