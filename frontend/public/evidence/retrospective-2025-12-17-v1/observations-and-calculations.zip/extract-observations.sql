-- Read-only bounded extraction for the evidence dates. No database operation is run by this package.
SELECT id,t,buy,sell,mid,source_observation,official_observation
FROM public.rates
WHERE t >= '2025-12-16T04:00:00Z' AND t < '2025-12-18T04:00:00Z'
ORDER BY t,id;
