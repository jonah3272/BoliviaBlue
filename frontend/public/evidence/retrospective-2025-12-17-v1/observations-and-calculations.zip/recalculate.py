#!/usr/bin/env python3
"""Read-only reproduction of the December 16–17 retrospective statistics."""
import json, csv, math, hashlib
from pathlib import Path
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from decimal import Decimal
from statistics import median

ROOT = Path(__file__).resolve().parent
TZ = ZoneInfo('America/La_Paz')
rows = json.loads((ROOT / 'rates-screened.json').read_text(), parse_float=Decimal)
rows = [r for r in rows if '2025-12-16' <= datetime.fromisoformat(r['t']).astimezone(TZ).date().isoformat() <= '2025-12-17']
rows.sort(key=lambda r: (datetime.fromisoformat(r['t']), r['id']))
out = {'timezone':'America/La_Paz', 'day_window':'[local midnight, next local midnight)', 'statistics_weight':'one equal weight per archived observation', 'days':{}}
for day in ['2025-12-16','2025-12-17']:
    a = [r for r in rows if datetime.fromisoformat(r['t']).astimezone(TZ).date().isoformat()==day]
    ts = [datetime.fromisoformat(r['t']).astimezone(TZ) for r in a]
    start = datetime.fromisoformat(day).replace(tzinfo=TZ)
    assert len({r['id'] for r in a}) == len(a)
    assert len(set(ts)) == len(a)
    assert all(all(math.isfinite(r[f]) and r[f]>0 for f in ['buy','sell','mid']) for r in a)
    assert all(abs(r['mid']-(r['buy']+r['sell'])/2) < Decimal('0.00001') for r in a)
    d = {'n':len(a), 'hours':len({t.hour for t in ts}), 'hour_counts':{str(h):sum(t.hour==h for t in ts) for h in range(24)}, 'first':ts[0].isoformat(), 'last':ts[-1].isoformat(), 'start_edge_seconds':(ts[0]-start).total_seconds(), 'end_edge_seconds':(start+timedelta(days=1)-ts[-1]).total_seconds(), 'max_gap_seconds':max((b-a).total_seconds() for a,b in zip(ts,ts[1:])), 'source_rows':sum(r['source_observation'] is not None for r in a), 'official_source_rows':sum(r['official_observation'] is not None for r in a), 'fields':{}}
    for f in ['buy','sell','mid']:
        v = [r[f] for r in a]
        delta=v[-1]-v[0]
        jumps=[{'start':ts[i-1].isoformat(),'end':ts[i].isoformat(),'from':v[i-1],'to':v[i],'change_pct':(v[i]/v[i-1]-1)*100} for i in range(1,len(v))]
        d['fields'][f] = {'first':v[0], 'last':v[-1], 'change':delta, 'change_pct':delta/v[0]*100,'minimum':min(v),'maximum':max(v),'mean':sum(v)/len(v),'median':median(v),'max_abs_adjacent_change':max(jumps,key=lambda x:abs(x['change_pct']))}
    out['days'][day] = d
out['daily_comparison']={f:{stat+'_change_pct':(out['days']['2025-12-17']['fields'][f][stat]/out['days']['2025-12-16']['fields'][f][stat]-1)*100 for stat in ['mean','median']} for f in ['buy','sell','mid']}
day17=[r for r in rows if datetime.fromisoformat(r['t']).astimezone(TZ).date().isoformat()=='2025-12-17']
out['late_segment']={'split':'2025-12-17T21:57:51.225-04:00','first_87_ranges':{f:[min(r[f] for r in day17[:87]),max(r[f] for r in day17[:87])] for f in ['buy','sell']},'last_9':[{**r,'bolivia_time':datetime.fromisoformat(r['t']).astimezone(TZ).isoformat()} for r in day17[87:]]}
(ROOT/'calculations.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str)+'\n')
with (ROOT/'observations-dec16-17.csv').open('w',newline='') as handle:
    w=csv.DictWriter(handle,fieldnames=['id','t','bolivia_time','buy','sell','mid','source_observation','official_observation']);w.writeheader()
    for r in rows:w.writerow({**r,'bolivia_time':datetime.fromisoformat(r['t']).astimezone(TZ).isoformat()})
print(json.dumps(out,ensure_ascii=False,indent=2,default=str))
