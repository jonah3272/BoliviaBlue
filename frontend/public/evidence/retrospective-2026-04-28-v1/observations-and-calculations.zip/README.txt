April 28, 2026 retrospective evidence, version 1

Period: April 27 and 28, 2026 in America/La_Paz (UTC-4).
This package contains 192 archived aggregate observations, an extraction query,
and an offline calculation program. Every source_observation is null.
It does not identify contributing platforms, original offers, cash prices, or
causes of price movements. It is not a provenance-validated daily report.

The observation JSON is an exact copy of the reviewed source snapshot.
SHA-256: 7580bce3c074f887e979a12ee538b8b85ebba7031c919c0cd6baaec74ca3c0a6

Run python3 reproduce.py in the extracted directory to reproduce and check
the calculations. Python standard library only; no database access required.
Review preparation dates are not the publication date of this retrospective.
The live article separately displays its actual revision timestamp.
