select id,t,created_at,buy::text buy,sell::text sell,mid::text mid,source_observation from public.rates where t >= '2026-04-27T04:00:00Z' and t < '2026-04-29T04:00:00Z' order by t;
