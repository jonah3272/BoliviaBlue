#!/usr/bin/env python3
"""Recalculate the bilingual retrospective from all 192 stored observations.

No network or dependencies. Decimal arithmetic; no interpolation or weighting.
Run python3 reproduce.py > recalculated-results.json
The output is checked against the independently verified October15 calculations.
"""
import hashlib
import json
from datetime import datetime, timedelta
from decimal import Decimal, getcontext
from pathlib import Path
from statistics import median
from zoneinfo import ZoneInfo

getcontext().prec = 40
BASE = Path(__file__).resolve().parent
TZ = ZoneInfo('America/La_Paz')
SOURCE = BASE / 'observations-2026-04-27_28.json'
rows = json.loads(SOURCE.read_text())
verified = json.loads((BASE/'calculations-independently-verified-20261015.json').read_text())
digest = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
assert digest == verified['source_snapshot_sha256'] == '7580bce3c074f887e979a12ee538b8b85ebba7031c919c0cd6baaec74ca3c0a6'
assert len(rows) == len({r['id'] for r in rows}) == len({r['t'] for r in rows}) == 192
assert all(r['source_observation'] is None for r in rows)
assert all(Decimal(r[k]) > 0 for r in rows for k in ('buy','sell','mid'))
assert all(abs(Decimal(r['mid'])-(Decimal(r['buy'])+Decimal(r['sell']))/2)<Decimal('0.000002') for r in rows)

def ts(v): return datetime.fromisoformat(v)
def pct(a,b): return (b/a-1)*100
def seconds(a,b): return Decimal(str((b-a).total_seconds()))

out={'source_snapshot_sha256':digest,'source_rows':len(rows),'days':{},'comparisons':{}}
for date in ('2026-04-27','2026-04-28'):
    day=[r for r in rows if ts(r['t']).astimezone(TZ).date().isoformat()==date]
    assert len(day)==96
    times=[ts(r['t']) for r in day]
    assert times == sorted(times)
    start=datetime.fromisoformat(date).replace(tzinfo=TZ)
    gaps=[seconds(a,b) for a,b in zip(times,times[1:])]
    delays=[seconds(ts(r['t']),ts(r['created_at'])) for r in day]
    item={'rows':len(day),
          'first_observation_local':times[0].astimezone(TZ).isoformat(),
          'last_observation_local':times[-1].astimezone(TZ).isoformat(),
          'unobserved_start_seconds':seconds(start,times[0]),
          'unobserved_end_seconds':seconds(times[-1],start+timedelta(days=1)),
          'adjacent_gap_seconds_min':min(gaps),
          'adjacent_gap_seconds_median':median(gaps),
          'adjacent_gap_seconds_max':max(gaps),
          'insert_delay_seconds_min':min(delays),
          'insert_delay_seconds_max':max(delays),
          'distinct_buy_sell_pairs':len({(r['buy'],r['sell']) for r in day}),
          'source_metadata_rows':0,'fields':{}}
    for k in ('buy','sell','mid'):
        vals=[Decimal(r[k]) for r in day]
        above=[i for i,v in enumerate(vals) if v>10]
        item['fields'][k]={
            'first':vals[0],'last':vals[-1],'min':min(vals),'max':max(vals),
            'mean':sum(vals)/len(vals),'median':median(vals),
            'first_last_absolute_change':vals[-1]-vals[0],
            'first_last_percent_change':pct(vals[0],vals[-1]),
            'observations_above_10':len(above),
            'first_observation_above_10_local':times[above[0]].astimezone(TZ).isoformat() if above else None,
            'all_later_observations_above_10':all(v>10 for v in vals[above[0]:]) if above else None}
    out['days'][date]=item
for k in ('buy','sell','mid'):
    a,b=[out['days'][d]['fields'][k] for d in ('2026-04-27','2026-04-28')]
    out['comparisons'][k]={'daily_mean_absolute_change':b['mean']-a['mean'],
        'daily_mean_percent_change':pct(a['mean'],b['mean']),
        'daily_last_observation_percent_change':pct(a['last'],b['last'])}
encoded=json.loads(json.dumps(out,default=str))
assert encoded['days']==verified['days']
assert encoded['comparisons']==verified['comparisons']
out['all_calculations_match_previous_independent_review']=True
out['calculation_note']='Equal-weight means of stored readings, not time-weighted or trading-volume-weighted. No interpolation. Source metadata unavailable in all rows.'
print(json.dumps(out,ensure_ascii=False,indent=2,default=str))
